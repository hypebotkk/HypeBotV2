### Oiin Sou o Toin
<a href="https://github.com/ToinNetuh" >

<br>




<summary>🍙 Ajuda!</summary>

## Precisa

```bash
> Termux
> WhatsApp
> 2 Celulares
```

---


## Instalação
Follow The Steps Below!

```bash
> termux-setup-storage
(De Acesso ao Armazenamento)
> apt install git -y
> git clone https://github.com/NazwaS/termux-whatsapp-bot
> cd termux-whatsapp-bot
> bash install.sh
```

## Use

```bash
> npm start
```

## Novidades
```
Depoix coloco
```

<img src="https://raw.githubusercontent.com/NazwaS/NazwaS/main/img/tenor.gif">
